public abstract class Munition	{

	private int portee;
	private int puissance;
	private int profondeur;

	public Munition()	{	}

	public abstract int getPuissance();

	public abstract int getPortee();

	public abstract int getProfondeur();
}
